package com.test.technical.cuenta_movimiento_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuentaMovimientoMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuentaMovimientoMsApplication.class, args);
	}

}
