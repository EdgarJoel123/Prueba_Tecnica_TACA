package com.test.technical.cuenta_movimiento_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuentaMovimientoMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
