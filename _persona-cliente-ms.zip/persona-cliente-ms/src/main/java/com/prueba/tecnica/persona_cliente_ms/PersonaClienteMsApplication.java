package com.prueba.tecnica.persona_cliente_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonaClienteMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonaClienteMsApplication.class, args);
	}

}
