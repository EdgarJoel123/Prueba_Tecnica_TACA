package com.prueba.tecnica.persona_cliente_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonaClienteMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
